/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab2;

import java.util.Scanner;

public class Lab2___2 {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        /*int number = 0;
        System.out.println(number);
        number += 1;
        System.out.println(number);
        number += 1;
        System.out.println(number);
        number += 1;
        System.out.println(number);
        number += 1;
        System.out.println(number);
        number += 1;
        System.out.println(number);*/
        
        System.out.println("Enter number of sekund: ");
        double second = sc.nextDouble();
        double hour = second/3600;
        System.out.println(second + " seconds is equivalent to " + hour + " hours");
        
        System.out.println("Enter radius: ");
        double rad = sc.nextDouble();
        double circumference = 2*3.142*rad;
        double area = 3.142*rad*rad;
        System.out.println("Circumference = " + circumference);
        System.out.println("Area = " + area);
        
        System.out.println("Please enter a number: ");
        int number = sc.nextInt();
        String result = number%2 == 0 ? "even":"odd";
        System.out.println(result);
        
    }
}
