import java.util.Scanner;

public class Lab4 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        /*int num=7;
        
        for(int i=0; i<num; i++){
            for(int j=0; j<num; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        
        int sum=0;
        
        for(int i=1; i<501; i++){
            sum = sum + i; 
        }
        System.out.print(sum);
        
        
        System.out.println("Number of line: ");
        int num = sc.nextInt();
        
        for(int i=1; i<=num; i++){
            if(i%2==0){
                System.out.println("+++++");
                
            }else{
                System.out.println("*****");
            }
        }
        
        String choice;
        do{
            System.out.println("Please key in your first number: ");
            int num1=sc.nextInt();
            System.out.println("Please key in your second number: ");
            int num2=sc.nextInt();

            int sum = num1 + num2;
            System.out.println("Sum = "+ sum);

            System.out.println("Do you want to continue? Please choose yes=y or no=n: ");
            choice = sc.next();
        }while(choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("Yes"));
        
        
        int min = 1;
        int max = 100;
        int ans = 63;
        int guess =0;
        
        while(ans!=guess){
            System.out.println("The number is between "+ min + "-" + max + ", your answer is?");
            guess = sc.nextInt();
            
            while(guess<min || guess>max){
                System.out.println("You must enter a number between " + min +"-" + max);
                guess = sc.nextInt();
            }
            
            if(guess<ans){
                min=guess;
            }else if(guess>ans){
                max=guess;
            }
        }
        
        int number = 4;
        System.out.println("Descending order");
        
        for(int i=number; i>0; i--){
            System.out.print(i);
            for(int j=0; j<i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        
        System.out.println("Ascending order");
        for(int i=1; i<number; i++){
            System.out.print(i);
            for(int j=0; j<i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        
        int row=4;
        int space=row-1;
        int star=1;
        
        for(int i=1; i<=row; i++){
            for(int j=0; j<space; j++){
                System.out.print(" ");
            }
            for(int j=0; j<star; j++){
                System.out.print("*");
            }
            space--;
            star+=2;
            System.out.println();
        }*/
    }
}
