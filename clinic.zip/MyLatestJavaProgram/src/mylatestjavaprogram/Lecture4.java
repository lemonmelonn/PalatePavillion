/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylatestjavaprogram;

/**
 *
 * @author HP
 */
public class Lecture4 {
    public static void main(String[]args){
        int start = 10;
        System.out.println(start + " in a bed and the little one said");
        while (start > 1){
            start--;
            System.out.println("Roll over, roll over");
            System.out.println("They all rolled over and one fell out,");
            System.out.println(start + " in a bed and the little one said");
        }
        System.out.println("Alone at last");
    }
}
