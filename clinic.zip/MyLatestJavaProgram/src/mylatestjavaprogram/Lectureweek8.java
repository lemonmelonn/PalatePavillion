package mylatestjavaprogram;

public class Lectureweek8 {
    public static void main(String[]args){
        FirstGUi firstpage = new FirstGUi();
    }
}
