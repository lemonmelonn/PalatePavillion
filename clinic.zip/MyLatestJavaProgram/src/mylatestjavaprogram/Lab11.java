package mylatestjavaprogram;

import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

public class Lab11 {
    public static void main(String[]args){
        /*Random rn = new Random();
        
        double number_ls[] = new double[100];
        double sum = 0;
        
        for(int i=0; i<number_ls.length; i++){
            number_ls[i] = rn.nextDouble();
        }
        
        for(double eachValue: number_ls){
            sum = sum + eachValue;
        }
        
        System.out.println("The sum of all elements in array is "+sum);
        
        --------------------------------------------------------------------
        
        Scanner sc = new Scanner(System.in);
        int number = 1000;
        
        while(number < 0 || number > 127){
            System.out.println("Please enter a number between 0-127: ");
            number = sc.nextInt();
        }
        
        char symbol = (char)number;
        System.out.println("The character of "+number+" is "+symbol);

        -------------------------------------------------------------------
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("First sentence: ");
        String firstsentence = sc.nextLine();
        
        System.out.println("Second sentence: ");
        String secondsentence = sc.nextLine();
        
        String fullsentence = firstsentence + " and " + secondsentence;
        System.out.println("Full sentence:"+ fullsentence);
        System.out.println("Lowercase:"+ fullsentence.toLowerCase());
        System.out.println("Uppercase:"+ fullsentence.toUpperCase());
        System.out.println("No space:"+ fullsentence.replace(" ", ""));
        
        -------------------------------------------------------------------
                
        String sentence = "Mary had a little lamb";
        
        System.out.println("First occurence of a is "+sentence.indexOf("a"));
        System.out.println("Last occurence of a is "+sentence.lastIndexOf("a"));
        
        -------------------------------------------------------------------*/
        Scanner sc = new Scanner(System.in);
        
        String fruit_ls[] = new String[10];
        
        for(int i=0; i<fruit_ls.length; i++){
            System.out.println("Please enter fruit name "+(i+1)+": ");
            fruit_ls[i] = sc.next();
        }
        
        System.out.println(Arrays.toString(fruit_ls));
        Arrays.sort(fruit_ls);
        System.out.println("After sorting: "+Arrays.toString(fruit_ls));
    }
}
