
package mylatestjavaprogram;

import java.io.*;
import java.util.Scanner;

public class Lab_13June {
    public static void main(String []args) throws IOException{
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Which fruit u wanna update quantity bruh?");
        String updatefruit = sc.next();
        
        System.out.println("New quantity: ");
        int updatequantity = sc.nextInt();
        
        FileReader fr = new FileReader("C:\\Users\\HP\\OneDrive\\Documents\\NetBeansProjects\\MyLatestJavaProgram\\record.txt");
        BufferedReader br = new BufferedReader(fr);
        
        String line = null;
        
        String[][]table = new String[100][];
        int row = 0;
        
        while((line = br.readLine()) != null){
            String values[] = line.split(",");
            if(updatefruit.equals(values[0])){
                values[1] = String.valueOf(updatequantity);
            }
            table[row] = values;
            row++;
            System.out.println(values[0]+" "+values[1]+" "+values[2]+" "+values[3]);
        }
        
        br.close();
        fr.close();
        
        FileWriter fw = new FileWriter("C:\\Users\\HP\\OneDrive\\Documents\\NetBeansProjects\\MyLatestJavaProgram\\record.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        
        for(int i=0; i<row; i++){
            String sentence = table[i][0]+","+table[i][1]+","+table[i][2]+","+table[i][3]+"\n";
            bw.write(sentence);
        }
        
        bw.close();
        fw.close();
        /*System.out.println("Fruit Name: ");
        String name = sc.next();
        
        System.out.println("Quantity: ");
        int quantity = sc.nextInt();
        
        System.out.println("Price: ");
        double price = sc.nextDouble();
        
        System.out.println("Supplier name: ");
        String supplier = sc.next();
        
        FileWriter fw = new FileWriter("C:\\Users\\HP\\OneDrive\\Documents\\NetBeansProjects\\MyLatestJavaProgram\\record.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);
        
        String line = name+","+quantity+","+price+","+supplier+"\n";
        
        bw.write(line);
        
        bw.close();
        fw.close();*/
    }
}
