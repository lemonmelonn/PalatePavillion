package mylatestjavaprogram;

import java.util.Scanner;

public class Lab5 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        /*int number_ls[]= {35, 28, 46, 71, 80, 58};
        int oddcount=0;
        int evencount=0;

        for(int i=0; i<6; i++){
            if(number_ls[i]%2==0){
                evencount+=1;
            }
            else{
                oddcount+=1;
            }
        }
        System.out.println("There are "+evencount+" even numbers and "+oddcount+" odd numbers in the array.");
        
        int number_ls[]= {75, 49, 30, 83, 203, 102};
        int largest=number_ls[0];
        
        for(int i=0; i<number_ls.length; i++){
            if(number_ls[i]>largest){
                largest=number_ls[i];
            }
        }
        
        System.out.println("The largest numebr is "+largest);
        
        int array1[]= {26, 3, 14, 8, 10};
        int array2[]= {11, 28, 24, 30, 12};
        int sOP=0;
        
        for(int i=0; i<array1.length; i++){
            int product=array1[i]*array2[i];
            sOP=sOP+product;
        }
        System.out.println("Sum of product = "+sOP);*/
        
        int num_ls1[]={9,12,27,31,48};
        int num_ls2[]={12,34,45,48,100};
        
        for(int i=0; i<num_ls1.length; i++){
            for(int j=0; j<num_ls2.length; j++){
                if (num_ls1[i]==num_ls2[j]){
                    System.out.println(num_ls1[i]);
                }
            }
        }
    }
}
