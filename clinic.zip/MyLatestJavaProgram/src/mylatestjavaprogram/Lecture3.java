/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylatestjavaprogram;

/**
 *
 * @author HP
 */
import java.util.Scanner;

public class Lecture3 {
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter age: ");
        int ageOfEntrant = sc.nextInt();
        
        double entryFee;
        
        if (ageOfEntrant <= 5){
            entryFee=0;
        }
        else if(ageOfEntrant >= 65){
            entryFee=1.50;
        }
        else{
            entryFee=2.50;
        }
        System.out.println("Entry fee is $"+entryFee);
    }
    
}
