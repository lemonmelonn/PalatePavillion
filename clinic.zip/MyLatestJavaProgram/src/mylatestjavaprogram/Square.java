package mylatestjavaprogram;

public class Square {
    private double length;
    
    public Square(double length){
        this.length=length;
    }
    
    public Square(){
        
    }
    
    public void setLength(double length){
        this.length=length;
    }
    
    public double getLength(){
        return length;
    }
    
    double getPerimeter(){
        double  perimeter = length*4;
        return perimeter;
    }
    
    double getArea(){
        double area = length*length;
        return area;
    }
}
