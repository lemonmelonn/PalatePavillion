package mylatestjavaprogram;

public class Cylinder extends Circle {
    private double height;
    
    public Cylinder(){
        super();
    }
    
    public Cylinder(double height){
        super();
        this.height=height;
    }
    
    public Cylinder(double radius, double height){
        super(radius);
        this.height=height;
    }
    
    public void setHeight(double height){
        this.height=height;
    }
    
    public double getHeight(){
        return height;
    }
    
    @Override
    public double getArea(){
        double area = (2*3.142*getRadius()*getRadius())+(2*3.142*getRadius()*height);
        return area;
    }
    
    public double getVolume(){
        double volume = 3.142*getRadius()*getRadius()*height;
        return volume;
    }
}
