/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mylatestjavaprogram;

public class MyLatestJavaProgram {

    public static void main(String[] args) {
        /*Circle c1 = new Circle();
        Circle c2 = new Circle(6);
        
        c1.setRadius(10);
        
        System.out.println("c1 area: "+c1.getArea());
        System.out.println("c2 area: "+c2.getArea());
        */
        Cylinder cy1 = new Cylinder();
        
        cy1.setRadius(7);
        cy1.setHeight(10);
        
        System.out.println("cy1 Area :"+cy1.getArea());
        System.out.println("cy1 Volume :"+cy1.getVolume());
        
        Sphere s1 = new Sphere();
        
        s1.setRadius(5);
        
        System.out.println("s1 Volume :"+s1.getVolume());
        System.out.println("s1 Area :"+s1.getArea());
    }
    
}
