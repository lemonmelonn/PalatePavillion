package mylatestjavaprogram;

public class Sphere extends Circle{
    
    public Sphere(){
        
    }
    
    public Sphere(double radius){
        super(radius);
    }
    
    public double getVolume(){
        double volume = (4*3.142*getRadius()*getRadius()*super.getRadius())/3;
        return volume;
    }
    
    public double getArea(){
        double area = 4*3.142*super.getRadius()*super.getRadius();
        return area;
    }
}
