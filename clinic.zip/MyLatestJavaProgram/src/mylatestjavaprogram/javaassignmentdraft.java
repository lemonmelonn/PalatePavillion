/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylatestjavaprogram;

/**
 *
 * @author HP
 */
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;

public class javaassignmentdraft {
    public static void main(String[] args){
        
        // CREATE TEXT FILE
        
        /*try{
            File myObj = new File("patientname.txt");
            if (myObj.createNewFile()){
                System.out.println("File created: " + myObj.getName());
            }else{
                System.out.println("File already exists.");
            }
        }catch(IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        
        // WRITE IN TEXT FILE
        
        try{
            FileWriter myWriter = new FileWriter("patientname.txt");
            myWriter.write("Jinx, Goblok fever");
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        }catch(IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }*/
        
        // READ FROM TEXT FILE
        
        try {
        FileReader reader = new FileReader("patientname.txt");
        int data = reader.read();
        while(data != -1) {
            System.out.print((char)data);
            data = reader.read();
        }
        reader.close();
   
        } catch (FileNotFoundException e) {
        e.printStackTrace();
        } catch (IOException e) {
        e.printStackTrace();
        }
    }
}
    

