
package mylatestjavaprogram;

public class Lab6 {
    public static void main(String[]args){
        /*Square smallSq = new Square(5);
        System.out.println(smallSq.getLength());
        System.out.println("smallSq perimeter: "+smallSq.getPerimeter());
        
        Square bigSq = new Square();
        //bigSq.length = 15
        bigSq.setLength(15);
        System.out.println("bigSq perimeter: "+bigSq.getPerimeter());*/
        
        BankAccount vikrant = new BankAccount(1234, 1000);
        System.out.println(vikrant.getBalance());
    }
}
