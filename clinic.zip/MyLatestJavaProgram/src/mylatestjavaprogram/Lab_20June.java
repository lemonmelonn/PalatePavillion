/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylatestjavaprogram;

import java.util.InputMismatchException;
import java.util.Scanner;
        
public class Lab_20June {
   /* public static void main(String[]args){
        Random rn = new Random();
        
        int number_ls[] = new int[5];
        
        for(int i=0; i<number_ls.length; i++){
            number_ls[i] = rn.nextInt(20,101);
        }
        
        for(int eachNumber: number_ls){
            System.out.println(eachNumber);
        }
        
        for(int i=0; i<number_ls.length; i++){
            System.out.println(number_ls[i]);
        }
    }*/
    
    public static void checkNumber(int number){
        if (number<0){
            throw new IllegalArgumentException();        }
    }
    
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        try{
            System.out.println("Please enter a number: ");
            int number = sc.nextInt();
            checkNumber(number);
   
        }catch(InputMismatchException e){
            System.out.println("It must be integer!");
        }catch(IllegalArgumentException e){
            System.out.println("It must be positive!");
        }
    }
    
}

