package mylatestjavaprogram;

import java.awt.*;

public class FirstGUi extends Frame {
    public FirstGUi(){
        Label welcometext = new Label("Jangan goblok");
        Label logintext = new Label("Tolong login");
        
        TextField input = new TextField(100);
        TextArea inputcok = new TextArea(5,5);
        
        Button okbutton = new Button("Press for Aimans tits");
        
        List mlitem = new List(3, false);
        mlitem.add("Clock");
        mlitem.add("WON");
        mlitem.add("Esme's ass");
        
        Choice gender = new Choice();
        gender.add("Lesbian");
        gender.add("Gay");
        gender.add("Ryan Gosling");
        
        Dialog digga = new Dialog(this, "Pop up Window");
        digga.setVisible(true);
        digga.setSize(100,200);
        digga.setLocation(300,100);
        
        add(welcometext);
        add(logintext);
        add(input);
        add(inputcok);
        add(okbutton);
        add(mlitem);
        add(gender);
        
        setSize(300, 300);
        setVisible(true);
        setLocation(500, 300);
        setTitle("This is my first frame");
        setLayout(new FlowLayout());
    }
}
