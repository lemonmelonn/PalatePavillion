/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylatestjavaprogram;

/**
 *
 * @author HP
 */
import java.util.Scanner;

public class Lab3 {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        /*System.out.println("Please enter an integer number: ");
        int num = sc.nextInt();
        
        if (num > 0){
            System.out.println("The number "+ num + " is a positive number."); 
        }else if(num == 0){
            System.out.println("The number "+ num + " is zero."); 
        }else{
            System.out.println("The number "+ num + " is a negative number."); 
        }
        
        System.out.println("Enter day number: ");
        int day = sc.nextInt();
        
        if (day == 1){
            System.out.println(day + " is Monday.");
        }else if (day == 2){
            System.out.println(day + " is Tuesday.");
        }else if (day == 3){
            System.out.println(day + " is Wednesday.");
        }else if (day == 4){
            System.out.println(day + " is Thursday.");
        }else if (day == 5){
            System.out.println(day + " is Friday.");
        }else if (day == 6){
            System.out.println(day + " is Saturday.");
        }else if (day == 7){
            System.out.println(day + " is Sunday.");
        }else{
            System.out.println(day + " is invalid.");
        }*/
        
        System.out.println("Please enter your first number: ");
        int firstnum = sc.nextInt();
        System.out.println("Please enter your second number: ");
        int secondnum = sc.nextInt();
        System.out.println("Please enter your third number: ");
        int thirdnum = sc.nextInt();
        
        int largest = firstnum;
        
        if (secondnum > largest){
            largest = secondnum;
        }
        
        if (thirdnum > largest){
            largest = thirdnum;
        }
        
        int smallest = firstnum;
        
        if (secondnum < smallest){
            smallest = secondnum;
        }
        
        if (thirdnum < smallest){
            smallest = thirdnum;
        }
        
        System.out.println("The largest number is " + largest + " and the smallest number is " + smallest);
     
    }
}
