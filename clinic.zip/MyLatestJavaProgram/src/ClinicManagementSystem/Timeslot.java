package ClinicManagementSystem;

public class Timeslot {
    private String doctorname;
    
    public Timeslot(){
        
    }
    
    public Timeslot(String doctorname){
        this.doctorname=doctorname;
    }
    
    public String getSchedule(){
        String schedule = doctorname + ":idrhi";
        return schedule;
    }
}
