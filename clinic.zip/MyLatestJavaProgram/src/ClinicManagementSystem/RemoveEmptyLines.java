package ClinicManagementSystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RemoveEmptyLines {

    public static void main(String[] args) {
        // Replace with your file paths
        String[] fileNames = {
            "C:\\Users\\HP\\OneDrive\\Documents\\NetBeansProjects\\MyLatestJavaProgram\\doctorschedule.txt"
            // Add more file paths as needed
        };

        for (String fileName : fileNames) {
            removeEmptyLines(fileName);
        }
    }

    public static void removeEmptyLines(String filename) {
        List<String> lines = new ArrayList<>();

        // Read the file and collect non-empty lines
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            // Optionally, show a dialog with the error
            JOptionPane.showMessageDialog(null, "Error reading the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write the non-empty lines back to the file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            for (String line : lines) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            // Optionally, show a dialog with the error
            JOptionPane.showMessageDialog(null, "Error writing to the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
