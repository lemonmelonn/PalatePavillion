/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.Scanner;
        
public class Lab2 {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Please enter a number: ");
        int number1 = sc.nextInt();
        
        System.out.println("Please enter another number: ");
        int number2 = sc.nextInt();
        
        int num = number1 + number2;
        System.out.println("The sum is: " + num);
        
        System.out.println("Enter your name: ");
        String name = sc.nextLine();
        System.out.println("Your name is " + name);
    }
}
